package naomiThing_2332244;
import java.awt.EventQueue;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ViewProgress extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextArea textArea;
    private JButton btnNewButton;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ViewProgress frame = new ViewProgress();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public ViewProgress() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 522, 562);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(29, 33, 68));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        setContentPane(contentPane);

        JLabel lblNewLabel = new JLabel("Student ID");
        lblNewLabel.setFont(new Font("Californian FB", Font.PLAIN, 15));
        lblNewLabel.setBackground(new Color(29, 33, 68));
        lblNewLabel.setForeground(new Color(239, 232, 180));
        lblNewLabel.setBounds(111, 55, 91, 22);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setFont(new Font("Californian FB", Font.PLAIN, 15));
        textField.setForeground(new Color(29, 33, 68));
        textField.setBounds(196, 57, 200, 20);
        contentPane.add(textField);
        textField.setColumns(10);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(64, 127, 387, 343);
        contentPane.add(scrollPane);

        textArea = new JTextArea();
        textArea.setFont(new Font("Californian FB", Font.PLAIN, 15));
        textArea.setForeground(new Color(29, 33, 68));
        textArea.setBackground(new Color(239, 232, 180));
        scrollPane.setViewportView(textArea);
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        
        btnNewButton = new JButton("Back");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		btnNewButton.setBorder(null);
        		Dashboard dashB = new Dashboard(null, null);
	            dashB.setVisible(true);
	            dispose();
        	}
        });
        btnNewButton.setBackground(new Color(239, 232, 180));
        btnNewButton.setForeground(new Color(29, 33, 68));
        btnNewButton.setFont(new Font("Californian FB", Font.PLAIN, 10));
        btnNewButton.setBounds(366, 494, 85, 21);
        contentPane.add(btnNewButton);
        
        textField.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                displayStudentInfo();
            }

            @Override
            public void keyPressed(KeyEvent e) {
            }
        });
    }

    private void displayStudentInfo() {
        String studentID = textField.getText();
        textArea.setText(fetchStudentInfoFromDatabase(studentID));
    }

    private String fetchStudentInfoFromDatabase(String studentID) {
        String url = "jdbc:mysql://localhost/cms";
        String username = "root";
        String password = "";
        StringBuilder studentInfo = new StringBuilder();
        if (studentID.equals("6712345")) {
        	try (Connection conn = DriverManager.getConnection(url, username, password)) {
                String query = "SELECT * FROM CreateReportCard2 WHERE StudentID = ?";
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setString(1, studentID);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                	studentInfo.append("StudentID: ").append(rs.getString("StudentID")).append("\n");
                    studentInfo.append("StudentName: ").append(rs.getString("StudentName")).append("\n");
                    studentInfo.append("Business Studies: ").append(rs.getString("BusinessStudies")).append("\n");
                    studentInfo.append("Finance: ").append(rs.getString("Finance")).append("\n");
                    studentInfo.append("Hotel Management: ").append(rs.getString("HotelManagement"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else {
        	try (Connection conn = DriverManager.getConnection(url, username, password)) {
                String query = "SELECT * FROM CreateReportCard1 WHERE StudentID = ?";
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setString(1, studentID);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    studentInfo.append("StudentID: ").append(rs.getString("StudentID")).append("\n");
                    studentInfo.append("StudentName: ").append(rs.getString("StudentName")).append("\n");
                    studentInfo.append("OODP: ").append(rs.getString("OODP")).append("\n");
                    studentInfo.append("C Programming: ").append(rs.getString("C")).append("\n");
                    studentInfo.append("Artificial Intelligence: ").append(rs.getString("AI"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        

        return studentInfo.toString();
    }
}
