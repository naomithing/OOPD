package naomiThing_2332244;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;


public class Dashboard extends SignIn {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTabbedPane tabbedPane;	
	private JTable table;
	private JTextField id;
	private JTextField seat;
	private JTextField name;
	private JTextField duration;
	private JTable table_1;
	private JTable table_2;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField TN;
	private JTextField TI;
	private JTextField TE;
	private JTextField TP;
	private JTextField SN;
	private JTextField SI;
	private JTextField SE;
	private JTextField SP;
	private JTextField SC;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dashboard frame = new Dashboard(null,null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void displayCourse() {
		String url = "jdbc:mysql://localhost/cms";
	    String username = "root";
	    String password = "";

	    try (Connection conn = DriverManager.getConnection(url, username, password)) {
	        String query = "SELECT * FROM cms.Course";
	        Statement stm = conn.createStatement();
	        ResultSet rs = stm.executeQuery(query);
	        
	        Vector<String> columnNames = new Vector<>();
	        columnNames.add("CourseID");
	        columnNames.add("CourseName");
	        columnNames.add("Seat");
	        columnNames.add("Duration");
	        
	        Vector<Vector<Object>> data = new Vector<>();
	        while (rs.next()) {
	            Vector<Object> row = new Vector<>();
	            row.add(rs.getObject("CourseID"));
	            row.add(rs.getObject("CourseName"));
	            row.add(rs.getObject("Seat"));
	            row.add(rs.getObject("Duration"));
	            data.add(row);
	        }

	        DefaultTableModel model = new DefaultTableModel(data, columnNames);

	        table.setModel(model);

	        conn.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
    }
	public void displayTutor() {
		String url = "jdbc:mysql://localhost/cms";
	    String username = "root";
	    String password = "";

	    try (Connection conn = DriverManager.getConnection(url, username, password)) {
	        String query = "SELECT * FROM cms.Tutor";
	        Statement stm = conn.createStatement();
	        ResultSet rs = stm.executeQuery(query);
	        
	        Vector<String> columnNames = new Vector<>();
	        columnNames.add("TutorID");
	        columnNames.add("TutorName");
	        columnNames.add("Email");
	        columnNames.add("Module");
	        
	        Vector<Vector<Object>> data = new Vector<>();
	        while (rs.next()) {
	            Vector<Object> row = new Vector<>();
	            row.add(rs.getObject("TutorID"));
	            row.add(rs.getObject("TutorName"));
	            row.add(rs.getObject("Email"));
	            row.add(rs.getObject("Module"));
	            data.add(row);
	        }

	        DefaultTableModel model = new DefaultTableModel(data, columnNames);

	        table_1.setModel(model);

	        conn.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
    }
	public void displayStudent() {
		String url = "jdbc:mysql://localhost/cms";
	    String username = "root";
	    String password = "";

	    try (Connection conn = DriverManager.getConnection(url, username, password)) {
	        String query = "SELECT * FROM cms.Student";
	        Statement stm = conn.createStatement();
	        ResultSet rs = stm.executeQuery(query);
	        
	        Vector<String> columnNames = new Vector<>();
	        columnNames.add("StudentID");
	        columnNames.add("StudentName");
	        columnNames.add("Email");
	        columnNames.add("PhoneNumber");
	        columnNames.add("Course");
	        
	        Vector<Vector<Object>> data = new Vector<>();
	        while (rs.next()) {
	            Vector<Object> row = new Vector<>();
	            row.add(rs.getObject("StudentID"));
	            row.add(rs.getObject("StudentName"));
	            row.add(rs.getObject("Email"));
	            row.add(rs.getObject("PhoneNumber"));
	            row.add(rs.getObject("Course"));
	            data.add(row);
	        }

	        DefaultTableModel model = new DefaultTableModel(data, columnNames);

	        table_2.setModel(model);

	        conn.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
    }
	private void deleteCourseFromDatabase(String courseId) {
	    try {
	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");

	        String sql = "DELETE FROM Course WHERE CourseID = ?";
	        PreparedStatement statement = connection.prepareStatement(sql);

	        statement.setString(1, courseId);
	        int rowsDeleted = statement.executeUpdate();
	        if (rowsDeleted > 0) {
	            JOptionPane.showMessageDialog(null, "Course deleted successfully.");
	        } else {
	            JOptionPane.showMessageDialog(null, "Failed to delete course.");
	        }
	        statement.close();
	        connection.close();
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	}
	
	private void updateDatabaseCourse(String courseId, int columnIndex, String newValue) {
	    try {
	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
	        String columnName = ""; // Set the appropriate column name based on columnIndex
	        switch (columnIndex) {
	            case 1:
	                columnName = "CourseName";
	                break;
	            case 0:
	                JOptionPane.showMessageDialog(null, "Cannot update CourseID.");
	                return; 
	            case 2:
	                columnName = "Seat";
	                break;
	            case 3:
	                columnName = "Duration";
	                break;
	            default:
	                break;
	        }

	        String sql = "UPDATE course SET " + columnName + " = ? WHERE CourseID = ?";
	        PreparedStatement statement = connection.prepareStatement(sql);

	        statement.setString(1, newValue);
	        statement.setString(2, courseId);

	        int rowsUpdated = statement.executeUpdate();
	        if (rowsUpdated > 0) {
	            JOptionPane.showMessageDialog(null, "Row updated successfully.");
	            table.getModel().setValueAt(newValue, table.getSelectedRow(), columnIndex);
	        } else {
	            JOptionPane.showMessageDialog(null, "Failed to update row.");
	        }

	        statement.close();
	        connection.close();
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
	    }
	}
	private void deleteTutorFromDatabase(String tutorId) {
	    try {
	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");

	        String sql = "DELETE FROM Tutor WHERE TutorID = ?";
	        PreparedStatement statement = connection.prepareStatement(sql);

	        statement.setString(1, tutorId);
	        int rowsDeleted = statement.executeUpdate();
	        if (rowsDeleted > 0) {
	            JOptionPane.showMessageDialog(null, "Tutor deleted successfully.");
	        }   
	        statement.close();
	        connection.close();
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	}
	
	private void deleteStudentFromDatabase(String studentId) {
	    try {
	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");

	        String sql = "DELETE FROM Student WHERE StudentID = ?";
	        PreparedStatement statement = connection.prepareStatement(sql);

	        statement.setString(1, studentId);
	        int rowsDeleted = statement.executeUpdate();
	        if (rowsDeleted > 0) {
	            JOptionPane.showMessageDialog(null, "Student deleted successfully.");
	        }   
	        statement.close();
	        connection.close();
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	}
	private void updateDatabaseTutor(String tutorId, int columnIndex, String newValue) {
	    try {
	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
	        String columnName = ""; 
	        switch (columnIndex) {
	            case 1:
	                columnName = "TutorName";
	                break;
	            case 0:
	                JOptionPane.showMessageDialog(null, "Cannot update TutorID.");
	                return; 
	            case 2:
	                columnName = "Email";
	                break;
	            case 3:
	                columnName = "PhoneNumber";
	                break;
	            default:
	                break;
	        }

	        String sql = "UPDATE tutor SET " + columnName + " = ? WHERE TutorID = ?";
	        PreparedStatement statement = connection.prepareStatement(sql);

	        statement.setString(1, newValue);
	        statement.setString(2, tutorId);

	        int rowsUpdated = statement.executeUpdate();
	        if (rowsUpdated > 0) {
	            JOptionPane.showMessageDialog(null, "Row updated successfully.");
	            table.getModel().setValueAt(newValue, table.getSelectedRow(), columnIndex);
	        } else {
	            JOptionPane.showMessageDialog(null, "Failed to update row.");
	        }

	        statement.close();
	        connection.close();
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
	    }
	}
	
	private void updateDatabaseStudent(String studentId, int columnIndex, String newValue) {
	    try {
	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
	        String columnName = ""; 
	        switch (columnIndex) {
	            case 1:
	                columnName = "StudentName";
	                break;
	            case 0:
	                JOptionPane.showMessageDialog(null, "Cannot update TutorID.");
	                return; 
	            case 2:
	                columnName = "Email";
	                break;
	            case 3:
	                columnName = "PhoneNumber";
	                break;
	            case 4:
	                columnName = "Course";
	                break;
	            default:
	                break;
	        }

	        String sql = "UPDATE student SET " + columnName + " = ? WHERE StudentID = ?";
	        PreparedStatement statement = connection.prepareStatement(sql);

	        statement.setString(1, newValue);
	        statement.setString(2, studentId);

	        int rowsUpdated = statement.executeUpdate();
	        if (rowsUpdated > 0) {
	            JOptionPane.showMessageDialog(null, "Row updated successfully.");
	            table_2.getModel().setValueAt(newValue, table_2.getSelectedRow(), columnIndex);
	        } else {
	            JOptionPane.showMessageDialog(null, "Failed to update row.");
	        }

	        statement.close();
	        connection.close();
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
	    }
	}
	public int getTotalCourseCount() {
        int totalCount = 0;
        String url = "jdbc:mysql://localhost/cms";
        String username = "root";
        String password = "";

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT COUNT(*) AS total FROM cms.Course";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            if (rs.next()) {
                totalCount = rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalCount;
    }

	public int getTotalTutorCount() {
        int totalCount = 0;
        String url = "jdbc:mysql://localhost/cms";
        String username = "root";
        String password = "";

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT COUNT(*) AS total FROM cms.Tutor";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            if (rs.next()) {
                totalCount = rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalCount;
    }
	
	public int getTotalStudentCount() {
        int totalCount = 0;
        String url = "jdbc:mysql://localhost/cms";
        String username = "root";
        String password = "";

        try (Connection conn = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT COUNT(*) AS total FROM cms.Student";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            if (rs.next()) {
                totalCount = rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalCount;
    }
	
	
	public Dashboard(String sm,String un) {
		setBackground(new Color(240, 240, 240));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1440, 706);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 240));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(29, 33, 68));
		panel.setBounds(0, 0, 225, 900);
		panel.setBackground(new Color(29, 33, 68));
		contentPane.add(panel);
		
		JButton Dbtn = new JButton("Dashboard");
		Dbtn.setBounds(57, 78, 100, 21);
		Dbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dbtn.setBorder(null);
				tabbedPane.setSelectedIndex(0);
			}
		});
		panel.setLayout(null);
		Dbtn.setForeground(new Color(29, 33, 68));
		Dbtn.setBackground(new Color(239, 232, 180));
		Dbtn.setFont(new Font("Californian FB", Font.BOLD, 12));
		panel.add(Dbtn);
		
		JButton Abtn = new JButton("Courses");
		Abtn.setBounds(57, 169, 100, 21);
		Abtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Abtn.setBorder(null);
				tabbedPane.setSelectedIndex(1);
			}
		});
		Abtn.setForeground(new Color(29, 33, 68));
		Abtn.setFont(new Font("Californian FB", Font.BOLD, 12));
		Abtn.setBackground(new Color(239, 232, 180));
		panel.add(Abtn);
		
		JButton Tbtn = new JButton("Tutor");
		Tbtn.setBounds(57, 260, 100, 21);
		Tbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Tbtn.setBorder(null);
				tabbedPane.setSelectedIndex(2);
			}
		});
		Tbtn.setForeground(new Color(29, 33, 68));
		Tbtn.setFont(new Font("Californian FB", Font.BOLD, 12));
		Tbtn.setBackground(new Color(239, 232, 180));
		panel.add(Tbtn);
		
		JButton Stdbtn = new JButton("Student");
		Stdbtn.setBounds(57, 351, 100, 21);
		Stdbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Stdbtn.setBorder(null);
				tabbedPane.setSelectedIndex(3);
			}
		});
		Stdbtn.setForeground(new Color(29, 33, 68));
		Stdbtn.setFont(new Font("Californian FB", Font.BOLD, 12));
		Stdbtn.setBackground(new Color(239, 232, 180));
		panel.add(Stdbtn);
		
		JButton Sbtn = new JButton("Settings");
		Sbtn.setBounds(57, 442, 100, 21);
		Sbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Sbtn.setBorder(null);
				tabbedPane.setSelectedIndex(4);
			}
		});
		Sbtn.setForeground(new Color(29, 33, 68));
		Sbtn.setFont(new Font("Californian FB", Font.BOLD, 12));
		Sbtn.setBackground(new Color(239, 232, 180));
		panel.add(Sbtn);
		
		JButton Lbtn = new JButton("Logout");
		Lbtn.setBounds(57, 533, 100, 21);
		Lbtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        Lbtn.setBorder(null);
		        int result = JOptionPane.showConfirmDialog(null, "Do you want to Logout?", "Logout", JOptionPane.YES_NO_OPTION);		        
		        if (result == JOptionPane.YES_OPTION) {
		            System.exit(0); 
		        } else {
		        	
		        }
		    }
		});

		Lbtn.setForeground(new Color(29, 33, 68));
		Lbtn.setFont(new Font("Californian FB", Font.BOLD, 12));
		Lbtn.setBackground(new Color(239, 232, 180));
		panel.add(Lbtn);

		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(222, -25, 1200, 900);
		contentPane.add(tabbedPane);
		
		JPanel Dpanel = new JPanel();
		Dpanel.setBackground(new Color(255, 250, 240));
		Dpanel.setForeground(new Color(255, 250, 240));
		tabbedPane.addTab("Dashboard", null, Dpanel, null);
		Dpanel.setLayout(null);
		
		JPanel A = new JPanel();
		A.setBackground(new Color(29, 33, 68));
		A.setForeground(new Color(255, 250, 240));
		A.setBounds(72, 124, 368, 184);
		Dpanel.add(A);
		A.setLayout(null);
		
		JLabel alvl = new JLabel("Total Courses");
		alvl.setForeground(new Color(239, 232, 180));
		alvl.setFont(new Font("Californian FB", Font.BOLD, 19));
		alvl.setBounds(10, 11, 142, 31);
		A.add(alvl);
		
		textField_6 = new JTextField();
		textField_6.setForeground(new Color(29, 33, 68));
		textField_6.setFont(new Font("Californian FB", Font.PLAIN, 40));
		textField_6.setBackground(new Color(239, 232, 180));
		textField_6.setBounds(163, 76, 36, 68);
		A.add(textField_6);
		textField_6.setColumns(10);
		textField_6.setText(String.valueOf(getTotalCourseCount()));
		
		JPanel T = new JPanel();
		T.setBackground(new Color(29, 33, 68));
		T.setBounds(561, 124, 368, 184);
		Dpanel.add(T);
		T.setLayout(null);
		
		JLabel tlvl = new JLabel("Total Tutor");
		tlvl.setForeground(new Color(239, 232, 180));
		tlvl.setFont(new Font("Californian FB", Font.BOLD, 19));
		tlvl.setBounds(10, 11, 131, 31);
		T.add(tlvl);
		
		textField_7 = new JTextField();
		textField_7.setForeground(new Color(29, 33, 68));
		textField_7.setFont(new Font("Californian FB", Font.PLAIN, 40));
		textField_7.setBackground(new Color(239, 232, 180));
		textField_7.setColumns(10);
		textField_7.setBounds(163, 76, 35, 68);
		T.add(textField_7);
		textField_7.setText(String.valueOf(getTotalTutorCount()));
		
		JPanel S = new JPanel();
		S.setBackground(new Color(29, 33, 68));
		S.setBounds(331, 393, 368, 184);
		Dpanel.add(S);
		S.setLayout(null);
		
		JLabel slvl = new JLabel("Total Student");
		slvl.setForeground(new Color(239, 232, 180));
		slvl.setFont(new Font("Californian FB", Font.BOLD, 19));
		slvl.setBounds(10, 11, 144, 31);
		S.add(slvl);
		
		textField_8 = new JTextField();
		textField_8.setForeground(new Color(29, 33, 68));
		textField_8.setFont(new Font("Californian FB", Font.PLAIN, 40));
		textField_8.setBackground(new Color(239, 232, 180));
		textField_8.setColumns(10);
		textField_8.setBounds(163, 76, 37, 68);
		S.add(textField_8);
		textField_8.setText(String.valueOf(getTotalStudentCount()));
		
		JLabel lblNewLabel_2 = new JLabel("Course Management System");
		lblNewLabel_2.setFont(new Font("Californian FB", Font.BOLD, 25));
		lblNewLabel_2.setForeground(new Color(29, 33, 68));
		lblNewLabel_2.setBounds(75, 45, 365, 42);
		Dpanel.add(lblNewLabel_2);
		
		JPanel Apanel = new JPanel();
		Apanel.setBackground(new Color(239, 232, 180));
		Apanel.setForeground(new Color(255, 250, 240));
		tabbedPane.addTab("Admin", null, Apanel, null);
		Apanel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(58, 270, 884, 500);
		Apanel.add(scrollPane);		
		
		table = new JTable();
		table.setForeground(new Color(188, 143, 143));
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Course Name", "Course ID", "Seat", "dutableration"				
			}
		));
		displayCourse();
		
		id = new JTextField();
		id.setBounds(401, 83, 275, 33);
		id.setForeground(new Color(29, 33, 68));
		Apanel.add(id);
		id.setColumns(10);
		
		seat = new JTextField();
		seat.setForeground(new Color(29, 33, 68));
		seat.setBounds(58, 183, 275, 33);
		Apanel.add(seat);
		seat.setColumns(10);
		
		name = new JTextField();
		name.setForeground(new Color(29, 33, 68));
		name.setBounds(58, 83, 275, 33);
		Apanel.add(name);
		name.setColumns(10);
		
		duration = new JTextField();
		duration.setForeground(new Color(29, 33, 68));
		duration.setBounds(401, 183, 275, 33);
		Apanel.add(duration);
		duration.setColumns(10);
		
		JButton addbtn = new JButton("Add");
		addbtn.setBounds(750, 80, 150, 40);
		addbtn.setBackground(new Color(29, 33, 68));
		addbtn.setForeground(new Color(239, 232, 180));
		addbtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		addbtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        addbtn.setBorder(null);
		        String url = "jdbc:mysql://localhost/cms";
		        String username = "root";
		        String passWord = "";

		        if (sm.equals("Admin")) {
		            DefaultTableModel model = (DefaultTableModel) table.getModel();
		            String data[] = {id.getText(), name.getText(), seat.getText(), duration.getText()};
		            model.addRow(data);
		            try {
		                Connection conn = DriverManager.getConnection(url, username, passWord);
		                Statement stm = conn.createStatement();

		                // Insert into Course table
		                String insertQuery = "INSERT INTO Course (CourseID, CourseName, Seat, Duration) VALUES('" + id.getText() + "', '" + name.getText() + "', '" + seat.getText() + "', '" + duration.getText() + "')";
		                stm.execute(insertQuery);

		                // Create new table for the course
		             // Create new table for the course with Semesters from FirstSem to EigthSem
		                String createTableQuery = "CREATE TABLE IF NOT EXISTS `" + name.getText() + "` (id INT AUTO_INCREMENT PRIMARY KEY, Semesters ENUM('FirstSem', 'SecondSem', 'ThirdSem', 'FourthSem', 'FifthSem', 'SixthSem', 'SeventhSem', 'EigthSem'), Module1 VARCHAR(255), Module2 VARCHAR(255), Module3 VARCHAR(255))";
		                stm.execute(createTableQuery);


		                System.out.println("Connection Successful");
		                conn.close();
		            } catch (Exception e1) {
		                e1.printStackTrace();
		            }
		        } else {
		            JOptionPane.showMessageDialog(null, "Access Denied! You don't have permission to perform this action.");
		        }
		    }
		});
		Apanel.add(addbtn);


		
		JLabel lblNewLabel = new JLabel("Course Name");
		lblNewLabel.setBounds(58, 40, 132, 33);
		lblNewLabel.setForeground(new Color(29, 33, 68));
		lblNewLabel.setFont(new Font("Californian FB", Font.BOLD, 20));
		Apanel.add(lblNewLabel);
		
		JLabel lblCourseId = new JLabel("Course ID");
		lblCourseId.setBounds(401, 40, 132, 33);
		lblCourseId.setForeground(new Color(29, 33, 68));
		lblCourseId.setFont(new Font("Californian FB", Font.BOLD, 20));
		Apanel.add(lblCourseId);
		
		JLabel lblSeat = new JLabel("Seat");
		lblSeat.setBounds(58, 140, 132, 33);
		lblSeat.setForeground(new Color(29, 33, 68));
		lblSeat.setFont(new Font("Californian FB", Font.BOLD, 20));
		Apanel.add(lblSeat);
		
		JLabel lblDuration = new JLabel("Duration");
		lblDuration.setBounds(401, 140, 132, 33);
		lblDuration.setForeground(new Color(29, 33, 68));
		lblDuration.setFont(new Font("Californian FB", Font.BOLD, 20));
		Apanel.add(lblDuration);
		
		JButton editbtn = new JButton("Edit");
		editbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (sm.equals("Admin")) {
					 int selectedRowIndex = table.getSelectedRow();
			            int selectedColumnIndex = table.getSelectedColumn();
			            if (selectedRowIndex != -1 && selectedColumnIndex != -1) {
			                DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
			                Object oldValue = table.getValueAt(selectedRowIndex, selectedColumnIndex);
			                String newValue = JOptionPane.showInputDialog(null, "Enter new value:", oldValue.toString());
			                if (newValue != null && !newValue.isEmpty()) {
			                    tableModel.setValueAt(newValue, selectedRowIndex, selectedColumnIndex);
			                    String courseId = tableModel.getValueAt(selectedRowIndex, 0).toString(); // Assuming CourseID is at index 1
			                    System.out.println(courseId);
			                    updateDatabaseCourse(courseId, selectedColumnIndex, newValue);
			                } else {
			                    JOptionPane.showMessageDialog(null, "Invalid value entered.");
			                }
			            } else {
			                JOptionPane.showMessageDialog(null, "Please select a cell to edit.");
			            }
	            } else {
	                JOptionPane.showMessageDialog(null, "Access Denied! You don't have permission to perform this action.");
	            }
			}
		});
		editbtn.setForeground(new Color(239, 232, 180));
		editbtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		editbtn.setBackground(new Color(29, 33, 68));
		editbtn.setBounds(750, 146, 150, 40);
		Apanel.add(editbtn);
		
		JButton detetebtn = new JButton("Delete");
		detetebtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (sm.equals("Admin")) {
					int selectedRowIndex = table.getSelectedRow();
		            if (selectedRowIndex != -1) {
		            	DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
		            	Object courseId = null;
		                for (int i = 0; i < table.getColumnCount(); i++) {
		                    if (table.getColumnName(i).equals("CourseID")) {
		                        courseId = table.getValueAt(selectedRowIndex, i);
		                        break;
		                    }
		                }
		                if (courseId != null) {
		                    deleteCourseFromDatabase(courseId.toString());
		                    tableModel.removeRow(selectedRowIndex);
		                } else {
		                    JOptionPane.showMessageDialog(null, "CourseID not found in the table.");
		                }
		            } else {
		                JOptionPane.showMessageDialog(null, "Please select a row to delete.");
		            }
	            } else {
	                JOptionPane.showMessageDialog(null, "Access Denied! You don't have permission to perform this action.");
	            }		
			}
		});
		detetebtn.setForeground(new Color(239, 232, 180));
		detetebtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		detetebtn.setBackground(new Color(29, 33, 68));
		detetebtn.setBounds(750, 211, 150, 40);
		Apanel.add(detetebtn);
		
		JPanel Tpanel = new JPanel();
		Tpanel.setForeground(new Color(255, 250, 240));
		Tpanel.setBackground(new Color(239, 232, 180));
		tabbedPane.addTab("Tutor", null, Tpanel, null);
		Tpanel.setLayout(null);
		
		JButton Taddbtn = new JButton("Add Tutor"); 
		Taddbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String url = "jdbc:mysql://localhost";
				String username = "root";
				String passWord = "";
	
			    if (sm.equals("Admin")) { 
			    	DefaultTableModel model = (DefaultTableModel)table_1.getModel();
		            String data[] = {TI.getText(),TN.getText(),TE.getText(),TP.getText()};
		            model.addRow(data);
		            try {
						Connection conn = DriverManager.getConnection(url, username, passWord);
						Statement stm = conn.createStatement();
					//	String query = "CREATE TABLE cms.Tutor (TutorID varchar(255), TutorName varchar(255), Email varchar(255), Module varchar(255))";
						String query = "insert into cms.Tutor values('"+TI.getText()+"', '"+TN.getText()+"', '"+TE.getText()+"', '"+TP.getText()+"')";
						System.out.println("Connection Successful");
						stm.execute(query);
						conn.close();
					}catch (Exception e1) {
						e1.printStackTrace();
					}
			    } else {
			        JOptionPane.showMessageDialog(null, "Access Denied! You don't have permission to perform this action.");
			    }
			}
		});
		Taddbtn.setForeground(new Color(239, 232, 180));
		Taddbtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		Taddbtn.setBackground(new Color(29, 33, 68));
		Taddbtn.setBounds(742, 70, 200, 30);
		Tpanel.add(Taddbtn);
		
		JButton Teditinfo = new JButton("Edit Info");
		Teditinfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (sm.equals("Admin")) {
					 int selectedRowIndex = table_1.getSelectedRow();
			            int selectedColumnIndex = table_1.getSelectedColumn();
			            if (selectedRowIndex != -1 && selectedColumnIndex != -1) {
			                DefaultTableModel tableModel = (DefaultTableModel) table_1.getModel();
			                Object oldValue = table_1.getValueAt(selectedRowIndex, selectedColumnIndex);
			                String newValue = JOptionPane.showInputDialog(null, "Enter new value:", oldValue.toString());
			                if (newValue != null && !newValue.isEmpty()) {
			                    tableModel.setValueAt(newValue, selectedRowIndex, selectedColumnIndex);
			                    String tutorId = tableModel.getValueAt(selectedRowIndex, 0).toString(); 
			                    System.out.println(tutorId);
			                    updateDatabaseTutor(tutorId, selectedColumnIndex, newValue);
			                } else {
			                    JOptionPane.showMessageDialog(null, "Invalid value entered.");
			                }
			            } else {
			                JOptionPane.showMessageDialog(null, "Please select a cell to edit.");
			            }
	            } else {
	                JOptionPane.showMessageDialog(null, "Access Denied! You don't have permission to perform this action.");
	            }
			}
		});
		Teditinfo.setForeground(new Color(239, 232, 180));
		Teditinfo.setFont(new Font("Californian FB", Font.BOLD, 20));
		Teditinfo.setBackground(new Color(29, 33, 68));
		Teditinfo.setBounds(742, 135, 200, 30);
		Tpanel.add(Teditinfo);
		
		JButton Tdeletebtn = new JButton("Delete Tutor");
		Tdeletebtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (sm.equals("Admin")) {
					int selectedRowIndex = table_1.getSelectedRow();
		            if (selectedRowIndex != -1) {
		            	DefaultTableModel tableModel = (DefaultTableModel) table_1.getModel();
		            	Object tutorId = null;
		                for (int i = 0; i < table_1.getColumnCount(); i++) {
		                    if (table_1.getColumnName(i).equals("TutorID")) {
		                    	tutorId = table_1.getValueAt(selectedRowIndex, i);
		                        break;
		                    }
		                }
		                if (tutorId != null) {
		                	deleteTutorFromDatabase(tutorId.toString());
		                    tableModel.removeRow(selectedRowIndex);
		                } else {
		                    JOptionPane.showMessageDialog(null, "TutorID not found in the table.");
		                }
		            } else {
		                JOptionPane.showMessageDialog(null, "Please select a row to delete.");
		            }
	            } else {
	                JOptionPane.showMessageDialog(null, "Access Denied! You don't have permission to perform this action.");
	            }
			}
		});
		Tdeletebtn.setForeground(new Color(239, 232, 180));
		Tdeletebtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		Tdeletebtn.setBackground(new Color(29, 33, 68));
		Tdeletebtn.setBounds(742, 200, 200, 30);
		Tpanel.add(Tdeletebtn);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(58, 260, 884, 500);
		Tpanel.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.setForeground(new Color(188, 143, 143));
		scrollPane_1.setViewportView(table_1);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Tutor Name", "Tutor ID", "Email", "Module"
			}
		));
		displayTutor();
		
		JLabel Tnamebtn = new JLabel("Tutor Name");
		Tnamebtn.setForeground(new Color(29, 33, 68));
		Tnamebtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		Tnamebtn.setBounds(58, 53, 132, 33);
		Tpanel.add(Tnamebtn);
		
		JLabel Tidbtn = new JLabel("Tutor ID");
		Tidbtn.setForeground(new Color(29, 33, 68));
		Tidbtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		Tidbtn.setBounds(397, 53, 132, 33);
		Tpanel.add(Tidbtn);
		
		JLabel Temailbtn = new JLabel("Email");
		Temailbtn.setForeground(new Color(29, 33, 68));
		Temailbtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		Temailbtn.setBounds(58, 165, 132, 33);
		Tpanel.add(Temailbtn);
		
		JLabel Tphnobtn = new JLabel("Module");
		Tphnobtn.setForeground(new Color(29, 33, 68));
		Tphnobtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		Tphnobtn.setBounds(397, 165, 132, 33);
		Tpanel.add(Tphnobtn);
		
		TN = new JTextField();
		TN.setForeground(new Color(29, 33, 68));
		TN.setColumns(10);
		TN.setBounds(58, 87, 275, 33);
		Tpanel.add(TN);
		
		TI = new JTextField();
		TI.setForeground(new Color(29, 33, 68));
		TI.setColumns(10);
		TI.setBounds(397, 83, 275, 33);
		Tpanel.add(TI);
		
		TE = new JTextField();
		TE.setForeground(new Color(29, 33, 68));
		TE.setColumns(10);
		TE.setBounds(58, 197, 275, 33);
		Tpanel.add(TE);
		
		TP = new JTextField();
		TP.setForeground(new Color(29, 33, 68));
		TP.setColumns(10);
		TP.setBounds(397, 197, 275, 33);
		Tpanel.add(TP);
		
		JPanel Stdpanel = new JPanel();
		Stdpanel.setForeground(new Color(255, 250, 240));
		Stdpanel.setBackground(new Color(239, 232, 180));
		tabbedPane.addTab("Student", null, Stdpanel, null);
		Stdpanel.setLayout(null);
		
		JButton Senrollbtn = new JButton("Enroll Student");
		Senrollbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String url = "jdbc:mysql://localhost";
				String username = "root";
				String passWord = "";
	
			    if (sm.equals("Student")) { 
			    	DefaultTableModel model = (DefaultTableModel)table_2.getModel();
		            String data[] = {SI.getText(),SN.getText(),SE.getText(),SP.getText(), SC.getText()};
		            model.addRow(data);
		            try {
						Connection conn = DriverManager.getConnection(url, username, passWord);
						Statement stm = conn.createStatement();
						//	String query = "CREATE TABLE cms.Student (StudentID varchar(255), StudentName varchar(255), Email varchar(255), PhoneNumber varchar(255), Course varchar(255))";
						String query = "insert into cms.Student values('"+SI.getText()+"', '"+SN.getText()+"', '"+SE.getText()+"', '"+SP.getText()+"', '"+SC.getText()+"')";
						System.out.println("Connection Successful");
						stm.execute(query);
						conn.close();
					}catch (Exception e1) {
						e1.printStackTrace();
					}
			    } else {
			        JOptionPane.showMessageDialog(null, "Enrollment is only for Students.");
			    }
			}
		});
		Senrollbtn.setForeground(new Color(239, 232, 180));
		Senrollbtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		Senrollbtn.setBackground(new Color(29, 33, 68));
		Senrollbtn.setBounds(520, 189, 180, 30);
		Stdpanel.add(Senrollbtn);
		
		JButton Seditinfo = new JButton("Edit Info");
		Seditinfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (sm.equals("Student")) {
					 int selectedRowIndex = table_2.getSelectedRow();
			            int selectedColumnIndex = table_2.getSelectedColumn();
			            if (selectedRowIndex != -1 && selectedColumnIndex != -1) {
			                DefaultTableModel tableModel = (DefaultTableModel) table_2.getModel();
			                Object oldValue = table_2.getValueAt(selectedRowIndex, selectedColumnIndex);
			                String newValue = JOptionPane.showInputDialog(null, "Enter new value:", oldValue.toString());
			                if (newValue != null && !newValue.isEmpty()) {
			                    tableModel.setValueAt(newValue, selectedRowIndex, selectedColumnIndex);
			                    String studentId = tableModel.getValueAt(selectedRowIndex, 0).toString(); 
			                    System.out.println(studentId);
			                    updateDatabaseStudent(studentId, selectedColumnIndex, newValue);
			                } else {
			                    JOptionPane.showMessageDialog(null, "Invalid value entered.");
			                }
			            } else {
			                JOptionPane.showMessageDialog(null, "Please select a cell to edit.");
			            }
	            } else {
	                JOptionPane.showMessageDialog(null, "Access Denied! You don't have permission to perform this action.");
	            }			}
		});
		Seditinfo.setForeground(new Color(239, 232, 180));
		Seditinfo.setFont(new Font("Californian FB", Font.BOLD, 20));
		Seditinfo.setBackground(new Color(29, 33, 68));
		Seditinfo.setBounds(105, 270, 180, 30);
		Stdpanel.add(Seditinfo);
		
		JButton Sdeletebtn = new JButton("Delete Student");
		Sdeletebtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (sm.equals("Admin")) {
					int selectedRowIndex = table_2.getSelectedRow();
		            if (selectedRowIndex != -1) {
		            	DefaultTableModel tableModel = (DefaultTableModel) table_2.getModel();
		            	Object studentId = null;
		                for (int i = 0; i < table_2.getColumnCount(); i++) {
		                    if (table_2.getColumnName(i).equals("StudentID")) {
		                    	studentId = table_2.getValueAt(selectedRowIndex, i);
		                        break;
		                    }
		                }
		                if (studentId != null) {
		                	deleteStudentFromDatabase(studentId.toString());
		                    tableModel.removeRow(selectedRowIndex);
		                } else {
		                    JOptionPane.showMessageDialog(null, "StudentID not found in the table.");
		                }
		            } else {
		                JOptionPane.showMessageDialog(null, "Please select a row to delete.");
		            }
	            } else {
	                JOptionPane.showMessageDialog(null, "Access Denied! You don't have permission to perform this action.");
	            }
			}
		});
		Sdeletebtn.setForeground(new Color(239, 232, 180));
		Sdeletebtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		Sdeletebtn.setBackground(new Color(29, 33, 68));
		Sdeletebtn.setBounds(412, 270, 180, 30);
		Stdpanel.add(Sdeletebtn);
		
		JButton Sviewbtn = new JButton("View Progress");
		Sviewbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Sviewbtn.setBorder(null);
				ViewProgress vp = new ViewProgress();
				vp.setVisible(true);
			}
		});
		Sviewbtn.setForeground(new Color(239, 232, 180));
		Sviewbtn.setFont(new Font("Californian FB", Font.BOLD, 20));
		Sviewbtn.setBackground(new Color(29, 33, 68));
		Sviewbtn.setBounds(717, 270, 180, 30);
		Stdpanel.add(Sviewbtn);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(58, 330, 877, 450);
		Stdpanel.add(scrollPane_2);
		
		table_2 = new JTable();
		table_2.setForeground(new Color(188, 143, 143));
		scrollPane_2.setViewportView(table_2);
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Student ID", "Student Name", "Email", "Phone Number", "Course"
			}
		));
		displayStudent();
		
		JLabel lblStudentName = new JLabel("Student Name");
		lblStudentName.setForeground(new Color(29, 33, 68));
		lblStudentName.setFont(new Font("Californian FB", Font.BOLD, 20));
		lblStudentName.setBounds(58, 30, 136, 33);
		Stdpanel.add(lblStudentName);
		
		JLabel lblStudentId = new JLabel("Student ID");
		lblStudentId.setForeground(new Color(29, 33, 68));
		lblStudentId.setFont(new Font("Californian FB", Font.BOLD, 20));
		lblStudentId.setBounds(550, 30, 104, 33);
		Stdpanel.add(lblStudentId);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setForeground(new Color(29, 33, 68));
		lblEmail.setFont(new Font("Californian FB", Font.BOLD, 20));
		lblEmail.setBounds(58, 110, 112, 33);
		Stdpanel.add(lblEmail);
		
		JLabel lblPhNo = new JLabel("Ph. no.");
		lblPhNo.setForeground(new Color(29, 33, 68));
		lblPhNo.setFont(new Font("Californian FB", Font.BOLD, 20));
		lblPhNo.setBounds(550, 110, 104, 33);
		Stdpanel.add(lblPhNo);
		
		SN = new JTextField();
		SN.setForeground(new Color(29, 33, 68));
		SN.setColumns(10);
		SN.setBounds(191, 30, 275, 33);
		Stdpanel.add(SN);
		
		SI = new JTextField();
		SI.setForeground(new Color(29, 33, 68));
		SI.setColumns(10);
		SI.setBounds(660, 30, 275, 33);
		Stdpanel.add(SI);
		
		SE = new JTextField();
		SE.setForeground(new Color(29, 33, 68));
		SE.setColumns(10);
		SE.setBounds(191, 110, 275, 33);
		Stdpanel.add(SE);
		
		SP = new JTextField();
		SP.setForeground(new Color(29, 33, 68));
		SP.setColumns(10);
		SP.setBounds(660, 116, 275, 33);
		Stdpanel.add(SP);
		
		JLabel lblCourse = new JLabel("Course ");
		lblCourse.setForeground(new Color(29, 33, 68));
		lblCourse.setFont(new Font("Californian FB", Font.BOLD, 20));
		lblCourse.setBounds(58, 188, 87, 33);
		Stdpanel.add(lblCourse);
		
		SC = new JTextField();
		SC.setForeground(new Color(29, 33, 68));
		SC.setColumns(10);
		SC.setBounds(191, 188, 275, 33);
		Stdpanel.add(SC);
		
		JButton btnGiveMarks = new JButton("Give Marks");
		btnGiveMarks.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (sm.equals("Instructor")) { 
					btnGiveMarks.setBorder(null);
					GiveMarks gm = new GiveMarks();
					gm.setVisible(true);
				}else {
					JOptionPane.showMessageDialog(null, "Access Denied! You don't have permission to perform this action.");
				}
			}
		});
		btnGiveMarks.setForeground(new Color(239, 232, 180));
		btnGiveMarks.setFont(new Font("Californian FB", Font.BOLD, 20));
		btnGiveMarks.setBackground(new Color(29, 33, 68));
		btnGiveMarks.setBounds(758, 189, 180, 30);
		Stdpanel.add(btnGiveMarks);
		
		JPanel Spanel = new JPanel();
		Spanel.setBackground(new Color(239, 232, 180));
		Spanel.setForeground(new Color(255, 250, 240));
		tabbedPane.addTab("Settings", null, Spanel, null);
		Spanel.setLayout(null);
		
		JLabel Setsettings = new JLabel("Settings");
		Setsettings.setForeground(new Color(29, 33, 68));
		Setsettings.setFont(new Font("Californian FB", Font.BOLD, 30));
		Setsettings.setBounds(10, 11, 179, 34);
		Spanel.add(Setsettings);
		
		JLabel Setgeneral = new JLabel("General Profile");
		Setgeneral.setForeground(new Color(29, 33, 68));
		Setgeneral.setFont(new Font("Californian FB", Font.BOLD, 19));
		Setgeneral.setBounds(20, 56, 156, 20);
		Spanel.add(Setgeneral);
		
		JLabel Setlvl1 = new JLabel("Username");
		Setlvl1.setForeground(new Color(29, 33, 68));
		Setlvl1.setFont(new Font("Californian FB", Font.BOLD, 15));
		Setlvl1.setBounds(79, 100, 80, 20);
		Spanel.add(Setlvl1);
		
		JLabel Setlvl2 = new JLabel("Ph. No. ");
		Setlvl2.setForeground(new Color(29, 33, 68));
		Setlvl2.setFont(new Font("Californian FB", Font.BOLD, 15));
		Setlvl2.setBounds(79, 150, 80, 20);
		Spanel.add(Setlvl2);
		
		JLabel Setlvl3 = new JLabel("Email");
		Setlvl3.setForeground(new Color(29, 33, 68));
		Setlvl3.setFont(new Font("Californian FB", Font.BOLD, 15));
		Setlvl3.setBounds(510, 100, 80, 20);
		Spanel.add(Setlvl3);
		
		JLabel Setlvl5 = new JLabel("Reg. Date");
		Setlvl5.setForeground(new Color(29, 33, 68));
		Setlvl5.setFont(new Font("Californian FB", Font.BOLD, 15));
		Setlvl5.setBounds(510, 150, 80, 20);
		Spanel.add(Setlvl5);
		
		textField = new JTextField();
		textField.setForeground(new Color(29, 33, 68));
		textField.setColumns(10);
		textField.setBounds(169, 98, 280, 25);
		Spanel.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setForeground(new Color(29, 33, 68));
		textField_1.setColumns(10);
		textField_1.setBounds(169, 145, 280, 25);
		Spanel.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setForeground(new Color(29, 33, 68));
		textField_2.setColumns(10);
		textField_2.setBounds(589, 100, 280, 25);
		Spanel.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setForeground(new Color(29, 33, 68));
		textField_3.setColumns(10);
		textField_3.setBounds(589, 145, 280, 25);
		Spanel.add(textField_3);
		
		JButton btnNewButton = new JButton("Save Changes");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Saved!");
			}
		});
		btnNewButton.setForeground(new Color(239, 232, 180));
		btnNewButton.setFont(new Font("Californian FB", Font.BOLD, 20));
		btnNewButton.setBackground(new Color(29, 33, 68));
		btnNewButton.setBounds(79, 216, 170, 30);
		Spanel.add(btnNewButton);
		
		JLabel lblSecurityLogin = new JLabel("Security & Login");
		lblSecurityLogin.setForeground(new Color(29, 33, 68));
		lblSecurityLogin.setFont(new Font("Californian FB", Font.BOLD, 16));
		lblSecurityLogin.setBounds(59, 285, 130, 20);
		Spanel.add(lblSecurityLogin);
		
		JLabel lblOldPassword = new JLabel("Old Password");
		lblOldPassword.setForeground(new Color(29, 33, 68));
		lblOldPassword.setFont(new Font("Californian FB", Font.BOLD, 15));
		lblOldPassword.setBounds(89, 326, 100, 20);
		Spanel.add(lblOldPassword);
		
		JLabel lblNewPassword = new JLabel("New Password");
		lblNewPassword.setForeground(new Color(29, 33, 68));
		lblNewPassword.setFont(new Font("Californian FB", Font.BOLD, 15));
		lblNewPassword.setBounds(529, 326, 100, 20);
		Spanel.add(lblNewPassword);
		
		textField_4 = new JTextField();
		textField_4.setForeground(new Color(29, 33, 68));
		textField_4.setColumns(10);
		textField_4.setBounds(199, 321, 280, 25);
		Spanel.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setForeground(new Color(29, 33, 68));
		textField_5.setColumns(10);
		textField_5.setBounds(655, 321, 280, 25);
		Spanel.add(textField_5);
		
		JButton btnChangepassword = new JButton("ChangePassword");
		btnChangepassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Password Changed!");
			}
		});
		btnChangepassword.setForeground(new Color(239, 232, 180));
		btnChangepassword.setFont(new Font("Californian FB", Font.BOLD, 20));
		btnChangepassword.setBackground(new Color(29, 33, 68));
		btnChangepassword.setBounds(79, 381, 190, 30);
		Spanel.add(btnChangepassword);
		
		JButton btnCreateAStudent = new JButton("Create a student report");
		btnCreateAStudent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCreateAStudent.setBorder(null);
				if (sm.equals("Admin")) { 
					ReportCard rc = new ReportCard();
					rc.setVisible(true);
				}else {
					JOptionPane.showMessageDialog(null, "Access Denied! You don't have permission to perform this action.");
				}
			}
		});
		btnCreateAStudent.setForeground(new Color(239, 232, 180));
		btnCreateAStudent.setFont(new Font("Californian FB", Font.BOLD, 20));
		btnCreateAStudent.setBackground(new Color(29, 33, 68));
		btnCreateAStudent.setBounds(79, 461, 300, 30);
		Spanel.add(btnCreateAStudent);
		
		JLabel lblHelpServices = new JLabel("Help & Services");
		lblHelpServices.setForeground(new Color(29, 33, 68));
		lblHelpServices.setFont(new Font("Californian FB", Font.BOLD, 19));
		lblHelpServices.setBounds(20, 528, 169, 20);
		Spanel.add(lblHelpServices);
		
		JLabel lblStudentGidelines = new JLabel("Student Gidelines?");
		lblStudentGidelines.setForeground(new Color(29, 33, 68));
		lblStudentGidelines.setFont(new Font("Californian FB", Font.BOLD, 15));
		lblStudentGidelines.setBounds(49, 559, 150, 20);
		Spanel.add(lblStudentGidelines);
		
		JLabel lblReportTechnicalIssues = new JLabel("Report technical issues?");
		lblReportTechnicalIssues.setForeground(new Color(29, 33, 68));
		lblReportTechnicalIssues.setFont(new Font("Californian FB", Font.BOLD, 15));
		lblReportTechnicalIssues.setBounds(209, 559, 170, 20);
		Spanel.add(lblReportTechnicalIssues);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome, "+un);
		lblNewLabel_1.setBounds(1233, 23, 236, 38);
		contentPane.add(lblNewLabel_1);
		lblNewLabel_1.setForeground(new Color(188, 143, 143));
		lblNewLabel_1.setFont(new Font("Californian FB", Font.BOLD, 20));
		
	}
}

