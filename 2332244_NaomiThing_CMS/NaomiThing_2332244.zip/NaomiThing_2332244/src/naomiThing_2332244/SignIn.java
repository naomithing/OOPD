package naomiThing_2332244;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JPasswordField;

public class SignIn extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField UN;
	public JComboBox SM;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignIn frame = new SignIn();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	} 
	private JPasswordField PW;
	/**
	 * Create the frame.
	 */
	public SignIn() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 730, 685);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(239, 232, 180));
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel login = new JLabel("SignIn");
		login.setForeground(new Color(29, 33, 68));
		login.setBackground(new Color(255, 245, 238));
		login.setFont(new Font("Californian FB", Font.BOLD, 28));
		login.setBounds(289, 64, 159, 41);
		contentPane.add(login);
		
		JLabel username = new JLabel("Username : ");
		username.setForeground(new Color(29, 33, 68));
		username.setBackground(new Color(29, 33, 68));
		username.setFont(new Font("Californian FB", Font.PLAIN, 22));
		username.setBounds(135, 191, 106, 33);
		contentPane.add(username);
		
		JLabel password = new JLabel("Password : ");
		password.setForeground(new Color(29, 33, 68));
		password.setFont(new Font("Californian FB", Font.PLAIN, 22));
		password.setBackground(new Color(188, 143, 143));
		password.setBounds(135, 299, 106, 33);
		contentPane.add(password);
		
		JLabel selectmode = new JLabel("Select Mode : ");
		selectmode.setForeground(new Color(29, 33, 68));
		selectmode.setFont(new Font("Californian FB", Font.PLAIN, 22));
		selectmode.setBackground(new Color(188, 143, 143));
		selectmode.setBounds(135, 402, 133, 33);
		contentPane.add(selectmode);
		
		UN = new JTextField();
		UN.setForeground(new Color(29, 33, 68));
		UN.setBounds(282, 187, 324, 33);
		contentPane.add(UN);
		UN.setColumns(10);
		
		PW = new JPasswordField();
		PW.setForeground(new Color(29, 33, 68));
		PW.setBounds(282, 299, 324, 33);
		contentPane.add(PW);
		
		SM = new JComboBox();
		SM.setBackground(new Color(255, 250, 240));
		SM.setModel(new DefaultComboBoxModel(new String[] {"                   -------Select-------", "Admin", "Instructor", "Student"}));
		SM.setFont(new Font("Californian FB", Font.PLAIN, 14));
		SM.setForeground(new Color(29, 33, 68));
		SM.setBounds(282, 399, 324, 33);
		contentPane.add(SM);
		
		
		JButton LB = new JButton("Login");
		LB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LB.setBorder(null);
				String Username = UN.getText();
				String Password = new String(PW.getPassword()); 
				String combo = (String) SM.getSelectedItem();
				String url = "jdbc:mysql://localhost";
				String username = "root";
				String password = "";
				
				try {
					Connection conn = DriverManager.getConnection(url, username, password);
					Statement stm = conn.createStatement();
					String query = "Select * from cms.info";
					System.out.println("Connection Successful");
					ResultSet rs = stm.executeQuery(query);
					boolean isValidUser = false;
					while(rs.next()) {
						 String dusername = rs.getString(4);
						 String dpassword = rs.getString(5);
						 
						 if(Username.equals(dusername) && Password.equals(dpassword)) {
							 isValidUser = true;
							 break;
						 }						 
					}
					if (isValidUser) {						
						 JOptionPane.showMessageDialog(null,"Succes");						 
						 Dashboard dashB = new Dashboard(combo, Username);
			             dashB.setVisible(true);
			             dispose();
					}else {
						if(Username.equals("") && Password.equals("")) {
							JOptionPane.showMessageDialog(null,"Field Can't be empty");
						}else {
							JOptionPane.showMessageDialog(null,"Invalid username or password");
						}			 
					}
					conn.close();
				}catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		LB.setBackground(new Color(29, 33, 68));
		LB.setForeground(new Color(239, 232, 180));
		LB.setFont(new Font("Californian FB", Font.BOLD, 20));
		LB.setBounds(135, 493, 471, 47);
		contentPane.add(LB);
		
		JButton SB = new JButton("Signup");
		SB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SB.setBorder(null);
				Register signup = new Register();
                signup.setVisible(true);
                dispose();   
			}
		});
		SB.setBackground(new Color(255, 250, 240));
		SB.setForeground(new Color(29, 33, 68));
		SB.setFont(new Font("Californian FB", Font.BOLD, 20));
		SB.setBounds(371, 557, 106, 31);
		contentPane.add(SB);
		
		JLabel noAcc = new JLabel("Don't have account?");
		noAcc.setForeground(new Color(29, 33, 68));
		noAcc.setFont(new Font("Californian FB", Font.BOLD, 15));
		noAcc.setBounds(248, 563, 129, 21);
		contentPane.add(noAcc);
		
	}
}
