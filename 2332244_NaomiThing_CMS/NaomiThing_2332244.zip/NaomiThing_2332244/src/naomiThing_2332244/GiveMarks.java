package naomiThing_2332244;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GiveMarks extends JFrame {
    private JTextField idField;
    private JTextField nameField;
    private JTextField courseField;
    private JComboBox<String> modulesComboBox;
    private JLabel markslvl;
    private JTextField entermarks;

    public GiveMarks() {
    	getContentPane().setBackground(new Color(29, 33, 68));
        setTitle("Student Lookup");
        setSize(430, 647);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel idLabel = new JLabel("Student ID");
        idLabel.setForeground(new Color(239, 232, 180));
        idLabel.setFont(new Font("Californian FB", Font.PLAIN, 15));
        idField = new JTextField(10);
        idField.setFont(new Font("Californian FB", Font.PLAIN, 15));
        idField.setForeground(new Color(29, 33, 68));
        JLabel nameLabel = new JLabel("Student Name");
        nameLabel.setFont(new Font("Californian FB", Font.PLAIN, 15));
        nameLabel.setForeground(new Color(239, 232, 180));
        nameField = new JTextField(20);
        nameField.setForeground(new Color(29, 33, 68));
        nameField.setFont(new Font("Californian FB", Font.PLAIN, 15));
        nameField.setEditable(false);
        JLabel courseLabel = new JLabel("Selected Course:");
        courseLabel.setFont(new Font("Californian FB", Font.PLAIN, 15));
        courseLabel.setForeground(new Color(239, 232, 180));
        courseField = new JTextField(20);
        courseField.setFont(new Font("Californian FB", Font.PLAIN, 15));
        courseField.setForeground(new Color(29, 33, 68));
        courseField.setEditable(false);

        JLabel modulesLabel = new JLabel("Modules:");
        modulesLabel.setForeground(new Color(239, 232, 180));
        modulesLabel.setFont(new Font("Californian FB", Font.PLAIN, 15));
        modulesComboBox = new JComboBox<>();
        modulesComboBox.setForeground(new Color(29, 33, 68));
        modulesComboBox.setFont(new Font("Californian FB", Font.PLAIN, 15));
        
        // Add action listener to the idField to update modules based on the selected course
        idField.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}

            @Override
            public void keyPressed(KeyEvent e) {}

            @Override
            public void keyReleased(KeyEvent e) {
                loadStudentDetails(); // Load student details based on the entered ID
            }
        });

        getContentPane().setLayout(null);
        idLabel.setBounds(61, 46, 118, 25);
        idField.setBounds(61, 70, 290, 25);
        nameLabel.setBounds(59, 141, 120, 25);
        nameField.setBounds(59, 166, 292, 25);
        courseLabel.setBounds(59, 255, 120, 25);
        courseField.setBounds(56, 280, 295, 25);
        modulesLabel.setBounds(61, 362, 80, 25);
        modulesComboBox.setBounds(60, 386, 291, 25);

        getContentPane().add(idLabel);
        getContentPane().add(idField);
        getContentPane().add(nameLabel);
        getContentPane().add(nameField);
        getContentPane().add(courseLabel);
        getContentPane().add(courseField);
        getContentPane().add(modulesLabel);
        getContentPane().add(modulesComboBox);
        
        markslvl = new JLabel("Enter Marks");
        markslvl.setForeground(new Color(239, 232, 180));
        markslvl.setFont(new Font("Californian FB", Font.PLAIN, 15));
        markslvl.setBounds(61, 455, 128, 25);
        getContentPane().add(markslvl);
        
        entermarks = new JTextField();
        entermarks.setForeground(new Color(29, 33, 68));
        entermarks.setFont(new Font("Californian FB", Font.PLAIN, 15));
        entermarks.setBounds(61, 481, 290, 25);
        getContentPane().add(entermarks);
        entermarks.setColumns(10);
        
        JButton btnNewButton = new JButton("Give Marks");
        btnNewButton.setBackground(new Color(239, 232, 180));
        btnNewButton.setForeground(new Color(29, 33, 68));
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		String url = "jdbc:mysql://localhost";
				String username = "root";
				String passWord = "";
				
				try {
					Connection conn = DriverManager.getConnection(url, username, passWord);
					Statement stm = conn.createStatement();
//					String query = "create table cms.ProgressReport(StudentID varchar(255), StudentName varchar(255), Course varchar(255), Modules varchar(255), MarksObtained varchar(255))"; 
					String query = "insert into cms.ProgressReport values('"+idField.getText()+"', '"+nameField.getText()+"', '"+courseField.getText()+"', '"+modulesComboBox.getSelectedItem()+"','"+entermarks.getText()+"')";
					JOptionPane.showMessageDialog(null,"Success");
					stm.execute(query);
					conn.close();
					
				}catch (Exception e1) {
					e1.printStackTrace();
				}
	            dispose();
        	}
        });
        btnNewButton.setFont(new Font("Californian FB", Font.PLAIN, 15));
        btnNewButton.setBounds(149, 553, 118, 21);
        getContentPane().add(btnNewButton);
    }

    private void loadStudentDetails() {
        String typedId = idField.getText();
        if (typedId.isEmpty()) {
            nameField.setText("");
            courseField.setText("");
            modulesComboBox.setModel(new DefaultComboBoxModel<>());
            return;
        }

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement stmt = conn.prepareStatement("SELECT StudentName, Course FROM Student WHERE StudentID = ?");
            stmt.setString(1, typedId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String studentName = rs.getString("StudentName");
                String courseName = rs.getString("Course");
                nameField.setText(studentName);
                courseField.setText(courseName);
                loadModules(courseName); // Load modules based on the selected course
            } else {
                nameField.setText("");
                courseField.setText("");
                modulesComboBox.setModel(new DefaultComboBoxModel<>());
                // Display "id not found" message
                System.out.println("id not found");
            }
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void loadModules(String courseName) {
        if (courseName.isEmpty()) {
            modulesComboBox.setModel(new DefaultComboBoxModel<>());
            return;
        }

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement stmt = conn.prepareStatement("SELECT Module1, Module2, Module3 FROM modules WHERE CourseName = ?");
            stmt.setString(1, courseName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String module1 = rs.getString("Module1");
                String module2 = rs.getString("Module2");
                String module3 = rs.getString("Module3");
                String[] modules = { "", module1, module2, module3 }; 
                modulesComboBox.setModel(new DefaultComboBoxModel<>(modules));
            } else {
                modulesComboBox.setModel(new DefaultComboBoxModel<>());
            }
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        GiveMarks lookup = new GiveMarks();
        lookup.setVisible(true);
    }
}