package naomiThing_2332244;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import javax.swing.JPasswordField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Register extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField FN;
	private JTextField LN;
	private JTextField EM;
	private JTextField UN;
	private JPasswordField NP;
	private JPasswordField CNP;
	private JComboBox comboBox;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Register() {
		setBackground(new Color(240, 240, 240));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 704, 684);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(239, 232, 180));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel signUplbl = new JLabel("Register ");
		signUplbl.setBackground(new Color(29, 33, 68));
		signUplbl.setForeground(new Color(29, 33, 68));
		signUplbl.setFont(new Font("Californian FB", Font.BOLD, 28));
		signUplbl.setBounds(257, 23, 204, 28);
		contentPane.add(signUplbl);
		
		JLabel firstname = new JLabel("Firstname : ");
		firstname.setForeground(new Color(29, 33, 68));
		firstname.setFont(new Font("Californian FB", Font.PLAIN, 22));
		firstname.setBounds(100, 105, 113, 24);
		contentPane.add(firstname);
		
		JLabel lastname = new JLabel("Lastname : ");
		lastname.setForeground(new Color(29, 33, 68));
		lastname.setFont(new Font("Californian FB", Font.PLAIN, 22));
		lastname.setBounds(100, 162, 113, 24);
		contentPane.add(lastname);
		
		JLabel email = new JLabel("Email : ");
		email.setForeground(new Color(29, 33, 68));
		email.setFont(new Font("Californian FB", Font.PLAIN, 22));
		email.setBounds(100, 225, 113, 24);
		contentPane.add(email);
		
		JLabel username = new JLabel("Username : ");
		username.setForeground(new Color(29, 33, 68));
		username.setFont(new Font("Californian FB", Font.PLAIN, 22));
		username.setBounds(100, 279, 113, 24);
		contentPane.add(username);
		
		JLabel newpassword = new JLabel("New Password : ");
		newpassword.setForeground(new Color(29, 33, 68));
		newpassword.setFont(new Font("Californian FB", Font.PLAIN, 22));
		newpassword.setBounds(100, 336, 161, 24);
		contentPane.add(newpassword);
		
		JLabel confirmpassword = new JLabel("Confirm Password : ");
		confirmpassword.setForeground(new Color(29, 33, 68));
		confirmpassword.setFont(new Font("Californian FB", Font.PLAIN, 22));
		confirmpassword.setBounds(100, 394, 194, 24);
		contentPane.add(confirmpassword);
		
		JLabel selectmode = new JLabel("Select Mode : ");
		selectmode.setForeground(new Color(29, 33, 68));
		selectmode.setFont(new Font("Californian FB", Font.PLAIN, 22));
		selectmode.setBounds(100, 450, 136, 24);
		contentPane.add(selectmode);
		
		JLabel lblAlreadyHaveAn = new JLabel("Already have an Account ? ");
		lblAlreadyHaveAn.setForeground(new Color(29, 33, 68));
		lblAlreadyHaveAn.setFont(new Font("Californian FB", Font.BOLD, 15));
		lblAlreadyHaveAn.setBounds(165, 578, 161, 28);
		contentPane.add(lblAlreadyHaveAn);
		
		FN = new JTextField();
		FN.setFont(new Font("Californian FB", Font.PLAIN, 15));
		FN.setForeground(new Color(29, 33, 68));
		FN.setBounds(285, 107, 271, 28);
		contentPane.add(FN);
		FN.setColumns(10);
		
		LN = new JTextField();
		LN.setFont(new Font("Californian FB", Font.PLAIN, 15));
		LN.setForeground(new Color(29, 33, 68));
		LN.setColumns(10);
		LN.setBounds(285, 164, 271, 28);
		contentPane.add(LN);
		
		EM = new JTextField();
		EM.setFont(new Font("Californian FB", Font.PLAIN, 15));
		EM.setForeground(new Color(29, 33, 68));
		EM.setColumns(10);
		EM.setBounds(285, 221, 271, 28);
		contentPane.add(EM);
		
		UN = new JTextField();
		UN.setForeground(new Color(29, 33, 68));
		UN.setFont(new Font("Californian FB", Font.PLAIN, 15));
		UN.setColumns(10);
		UN.setBounds(285, 275, 271, 28);
		contentPane.add(UN);
		
		NP = new JPasswordField();
		NP.setFont(new Font("Californian FB", Font.PLAIN, 15));
		NP.setForeground(new Color(29, 33, 68));
		NP.setBounds(285, 333, 271, 28);
		contentPane.add(NP);
		
		CNP = new JPasswordField();
		CNP.setForeground(new Color(29, 33, 68));
		CNP.setFont(new Font("Californian FB", Font.PLAIN, 15));
		CNP.setBounds(285, 390, 271, 28);
		contentPane.add(CNP);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"                   -------Select-------", "Admin", "Instructor", "Student"}));
		comboBox.setFont(new Font("Californian FB", Font.PLAIN, 14));
		comboBox.setBackground(new Color(255, 250, 240));
		comboBox.setForeground(new Color(29, 33, 68));
		comboBox.setBounds(285, 448, 271, 28);
		contentPane.add(comboBox);
		
		JButton signup = new JButton("Sign Up");
		signup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				signup.setVisible(true);
				signup.setBorder(null);
				String FirstName = FN.getText();
				String LastName = LN.getText();
				String Email = EM.getText();
				String Username = UN.getText();
				String NewPassword = new String(NP.getPassword()); 
				String ConfirmPassword = new String(CNP.getPassword());
				
				System.out.println(FirstName);
				System.out.println(LastName);
				System.out.println(Email);
				System.out.println(Username);
				System.out.println(NewPassword);
				System.out.println(ConfirmPassword);
				
				String regexE = "[a-zA-Z_]+[a-zA-Z0-9_.]+[@]+[a-z]+[.][]a-z]{2,}";
				Pattern EMail = Pattern.compile(regexE);
				Matcher EMAIL = EMail.matcher(Email);
				boolean email = EMAIL.matches();
				
				String regexF = "^[A-Z][a-z]+$";
				Pattern firstName = Pattern.compile(regexF);				
				Matcher FIRSTNAME = firstName.matcher(FirstName);
				boolean firstname = FIRSTNAME.matches();
			
				String regexL = "^[a-zA-Z]+$";
				Pattern lastName = Pattern.compile(regexL);				
				Matcher LASTNAME = lastName.matcher(LastName);
				boolean lastname = LASTNAME.matches();
				
				String regexP = "[a-zA-Z]+[@&]\\d+";
				Pattern Password = Pattern.compile(regexP);				
				Matcher PASSWORD = Password.matcher(NewPassword);
				boolean password = PASSWORD.matches();
					
				boolean isConfirmationPasswordValid = ConfirmPassword.equals(NewPassword);
				
				if (!FirstName.equals("")&& !LastName.equals("") && !Email.equals("") && !NewPassword.equals("") && !ConfirmPassword.equals("") && isConfirmationPasswordValid){
					
					JOptionPane.showMessageDialog(null, "Signed Up Successfully!"); 
					
					String url = "jdbc:mysql://localhost";
					String username = "root";
					String passWord = "";
					
					try {
						Connection conn = DriverManager.getConnection(url, username, passWord);
						Statement stm = conn.createStatement();
						String query = "insert into cms.info values('"+FN.getText()+"', '"+LN.getText()+"', '"+EM.getText()+"', '"+UN.getText()+"','"+new String(NP.getPassword())+"', '"+comboBox.getSelectedItem()+"')";
						System.out.println("Connection Successful");
						stm.execute(query);
						conn.close();
					}catch (Exception e1) {
						e1.printStackTrace();
					}
				}else {
					if (!firstname) 
						JOptionPane.showMessageDialog(null,"Field can't be empty!");
					if (!lastname)
						JOptionPane.showMessageDialog(null,"Field can't be empty!");
					if(!email)
						JOptionPane.showMessageDialog(null,"Field can't be empty!");
					if (!password)
						JOptionPane.showMessageDialog(null,"Field can't be empty!");
					if(!isConfirmationPasswordValid)
						JOptionPane.showMessageDialog(null,"Password do not match");
				}
				//--------------------------
			}
		});
		signup.setBackground(new Color(29, 33, 68));
		signup.setForeground(new Color(255, 250, 240));
		signup.setFont(new Font("Californian FB", Font.BOLD, 20));
		signup.setBounds(100, 522, 456, 42);
		contentPane.add(signup);
		
		JButton login = new JButton("Login");
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login.setBorder(null);
				SignIn login = new SignIn();
                login.setVisible(true);
                dispose();
				//--------------------------------
			}
		});
		login.setForeground(new Color(29, 33, 68));
		login.setFont(new Font("Californian FB", Font.BOLD, 20));
		login.setBackground(new Color(255, 250, 240));
		login.setBounds(336, 577, 97, 28);
		contentPane.add(login);
		
	}
}
