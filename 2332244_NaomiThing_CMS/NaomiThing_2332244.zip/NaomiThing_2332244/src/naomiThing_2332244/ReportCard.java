package naomiThing_2332244;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ReportCard extends JFrame {
    // Declare components
    private JTextField idField;
    private JTextField nameField;
    private JTextField courseField;
    private JComboBox<String> modulesComboBox;
    private JComboBox<String> modulesComboBox_1;
    private JComboBox<String> modulesComboBox_2;
    private JTextField entermarks;
    private JTextField entermarks_1;
    private JTextField entermarks_2;
    private JButton btnNewButton;

    public ReportCard() {
        // Set frame properties
        setTitle("Student Lookup");
        setSize(709, 737);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(29, 33, 68));

        // Create and position components
        JLabel idLabel = new JLabel("Student ID");
        idLabel.setBounds(61, 46, 118, 25);
        idLabel.setForeground(new Color(239, 232, 180));
        idLabel.setFont(new Font("Californian FB", Font.PLAIN, 15));
        idField = new JTextField(10);
        idField.setBounds(61, 70, 362, 25);
        idField.setFont(new Font("Californian FB", Font.PLAIN, 15));
        idField.setForeground(new Color(188, 143, 143));
        JLabel nameLabel = new JLabel("Student Name");
        nameLabel.setBounds(59, 141, 120, 25);
        nameLabel.setFont(new Font("Californian FB", Font.PLAIN, 15));
        nameLabel.setForeground(new Color(239, 232, 180));
        nameField = new JTextField(20);
        nameField.setBounds(61, 166, 362, 25);
        nameField.setForeground(new Color(188, 143, 143));
        nameField.setFont(new Font("Californian FB", Font.PLAIN, 15));
        nameField.setEditable(false);
        JLabel courseLabel = new JLabel("Selected Course:");
        courseLabel.setBounds(59, 245, 120, 25);
        courseLabel.setFont(new Font("Californian FB", Font.PLAIN, 15));
        courseLabel.setForeground(new Color(239, 232, 180));
        courseField = new JTextField(20);
        courseField.setBounds(61, 274, 362, 25);
        courseField.setFont(new Font("Californian FB", Font.PLAIN, 15));
        courseField.setForeground(new Color(188, 143, 143));
        courseField.setEditable(false);

        JLabel modulesLabel = new JLabel("Module1");
        modulesLabel.setBounds(61, 362, 80, 25);
        modulesLabel.setForeground(new Color(239, 232, 180));
        modulesLabel.setFont(new Font("Californian FB", Font.PLAIN, 15));
        modulesComboBox = new JComboBox<>();
        modulesComboBox.setBounds(133, 362, 290, 25);
        modulesComboBox.setForeground(new Color(29, 33, 68));
        modulesComboBox.setFont(new Font("Californian FB", Font.PLAIN, 15));

        JLabel modulesLabel_1 = new JLabel("Module2");
        modulesLabel_1.setBounds(61, 457, 85, 25);
        modulesLabel_1.setForeground(new Color(239, 232, 180));
        modulesLabel_1.setFont(new Font("Californian FB", Font.PLAIN, 15));
        modulesComboBox_1 = new JComboBox<>();
        modulesComboBox_1.setBounds(133, 458, 290, 25);
        modulesComboBox_1.setFont(new Font("Californian FB", Font.PLAIN, 15));
        modulesComboBox_1.setForeground(new Color(29, 33, 68));

        JLabel modulesLabel_2 = new JLabel("Module3");
        modulesLabel_2.setBounds(61, 559, 85, 25);
        modulesLabel_2.setForeground(new Color(239, 232, 180));
        modulesLabel_2.setFont(new Font("Californian FB", Font.PLAIN, 15));
        modulesComboBox_2 = new JComboBox<>();
        modulesComboBox_2.setBounds(133, 560, 290, 25);
        modulesComboBox_2.setFont(new Font("Californian FB", Font.PLAIN, 15));
        modulesComboBox_2.setForeground(new Color(29, 33, 68));

        JLabel marksLabel = new JLabel("Enter Marks for Module1:");
        marksLabel.setBounds(61, 399, 200, 25);
        marksLabel.setForeground(new Color(239, 232, 180));
        marksLabel.setFont(new Font("Californian FB", Font.PLAIN, 15));
        entermarks = new JTextField();
        entermarks.setBounds(280, 399, 143, 25);
        entermarks.setFont(new Font("Californian FB", Font.PLAIN, 15));
        entermarks.setForeground(new Color(29, 33, 68));

        JLabel marksLabel_1 = new JLabel("Enter Marks for Module2:");
        marksLabel_1.setBounds(61, 493, 200, 25);
        marksLabel_1.setForeground(new Color(239, 232, 180));
        marksLabel_1.setFont(new Font("Californian FB", Font.PLAIN, 15));
        entermarks_1 = new JTextField();
        entermarks_1.setBounds(280, 493, 143, 25);
        entermarks_1.setFont(new Font("Californian FB", Font.PLAIN, 15));
        entermarks_1.setForeground(new Color(29, 33, 68));

        JLabel marksLabel_2 = new JLabel("Enter Marks for Module3:");
        marksLabel_2.setBounds(61, 595, 200, 25);
        marksLabel_2.setForeground(new Color(239, 232, 180));
        marksLabel_2.setFont(new Font("Californian FB", Font.PLAIN, 15));
        entermarks_2 = new JTextField();
        entermarks_2.setBounds(280, 595, 143, 25);
        entermarks_2.setFont(new Font("Californian FB", Font.PLAIN, 15));
        entermarks_2.setForeground(new Color(29, 33, 68));

        // Add action listener to the idField to update modules based on the selected course
        idField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                loadStudentDetails(); // Load student details based on the entered ID
            }
        });
        getContentPane().setLayout(null);

        // Add components to the content pane
        getContentPane().add(idLabel);
        getContentPane().add(idField);
        getContentPane().add(nameLabel);
        getContentPane().add(nameField);
        getContentPane().add(courseLabel);
        getContentPane().add(courseField);
        getContentPane().add(modulesLabel);
        getContentPane().add(modulesComboBox);
        getContentPane().add(modulesLabel_1);
        getContentPane().add(modulesComboBox_1);
        getContentPane().add(modulesLabel_2);
        getContentPane().add(modulesComboBox_2);
        getContentPane().add(marksLabel);
        getContentPane().add(entermarks);
        getContentPane().add(marksLabel_1);
        getContentPane().add(entermarks_1);
        getContentPane().add(marksLabel_2);
        getContentPane().add(entermarks_2);
        
        btnNewButton = new JButton("Create");
        btnNewButton.setBounds(500, 600, 110, 27);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		System.out.println(courseField.getText());
        		String url = "jdbc:mysql://localhost/cms";
    			String username = "root";
    			String passWord = "";
        		if ("Bsc (Hons) Computer Science".equals(courseField.getText())) {
        			try {
        				Connection conn = DriverManager.getConnection(url, username, passWord);
        				Statement stm = conn.createStatement();
 //       				String query = "create table cms.CreateReportCard1(StudentID varchar(255), StudentName varchar(255), Course varchar(255), OODP varchar(255), C varchar(255), AI varchar(255))"; 
						String query = "insert into cms.CreateReportCard1 values('"+idField.getText()+"', '"+nameField.getText()+"', '"+courseField.getText()+"', '"+entermarks.getText()+"','"+entermarks_1.getText()+"','"+entermarks_2.getText()+"')";
        				JOptionPane.showMessageDialog(null,"Success");
        				stm.execute(query);
        				conn.close();
					
        			}catch (Exception e1) {
        				e1.printStackTrace();
        			}
        			dispose();
        		}else {
        			try {
        				Connection conn = DriverManager.getConnection(url, username, passWord);
        				Statement stm = conn.createStatement();
//        				String query = "create table cms.CreateReportCard2(StudentID varchar(255), StudentName varchar(255), Course varchar(255),BusinessStudies varchar(255), Finance varchar(255), HotelManagement varchar(255))"; 
						String query = "insert into cms.CreateReportCard2 values('"+idField.getText()+"', '"+nameField.getText()+"', '"+courseField.getText()+"', '"+entermarks.getText()+"','"+entermarks_1.getText()+"', '"+entermarks_2.getText()+"')";
        				JOptionPane.showMessageDialog(null,"Success");
        				stm.execute(query);
        				conn.close();
					
        			}catch (Exception e1) {
        				e1.printStackTrace();
        			}
        			dispose();
        		}
        	}
        });
        btnNewButton.setFont(new Font("Californian FB", Font.PLAIN, 15));
        btnNewButton.setBackground(new Color(239, 232, 180));
        btnNewButton.setForeground(new Color(29, 33, 68));
        getContentPane().add(btnNewButton);
    }

    private void loadStudentDetails() {
        String typedId = idField.getText();
        if (typedId.isEmpty()) {
            nameField.setText("");
            courseField.setText("");
            modulesComboBox.setModel(new DefaultComboBoxModel<>());
            modulesComboBox_1.setModel(new DefaultComboBoxModel<>());
            modulesComboBox_2.setModel(new DefaultComboBoxModel<>());
            return;
        }

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement stmt = conn.prepareStatement("SELECT StudentName, Course FROM Student WHERE StudentID = ?");
            stmt.setString(1, typedId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String studentName = rs.getString("StudentName");
                String courseName = rs.getString("Course");
                nameField.setText(studentName);
                courseField.setText(courseName);
                loadModules(courseName); // Load modules based on the selected course
            } else {
                nameField.setText("");
                courseField.setText("");
                modulesComboBox.setModel(new DefaultComboBoxModel<>());
                modulesComboBox_1.setModel(new DefaultComboBoxModel<>());
                modulesComboBox_2.setModel(new DefaultComboBoxModel<>());
                // Display "id not found" message
                System.out.println("id not found");
            }
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void loadModules(String courseName) {
        if (courseName.isEmpty()) {
            modulesComboBox.setModel(new DefaultComboBoxModel<>());
            modulesComboBox_1.setModel(new DefaultComboBoxModel<>());
            modulesComboBox_2.setModel(new DefaultComboBoxModel<>());
            return;
        }

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/cms", "root", "");
            PreparedStatement stmt = conn.prepareStatement("SELECT Module1, Module2, Module3 FROM modules WHERE CourseName = ?");
            stmt.setString(1, courseName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String module1 = rs.getString("Module1");
                String module2 = rs.getString("Module2");
                String module3 = rs.getString("Module3");
                String[] modules = { "", module1, module2, module3 };
                modulesComboBox.setModel(new DefaultComboBoxModel<>(modules));
                modulesComboBox_1.setModel(new DefaultComboBoxModel<>(modules));
                modulesComboBox_2.setModel(new DefaultComboBoxModel<>(modules));
            } else {
                modulesComboBox.setModel(new DefaultComboBoxModel<>());
                modulesComboBox_1.setModel(new DefaultComboBoxModel<>());
                modulesComboBox_2.setModel(new DefaultComboBoxModel<>());
            }
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        ReportCard lookup = new ReportCard();
        lookup.setVisible(true);
    }
}
